(()=>{var C={chatgpt:{id:"chatgpt",name:"ChatGPT",url:"https://chatgpt.com",characterLimit:4e4},claude:{id:"claude",name:"Claude",url:"https://claude.ai/new",characterLimit:5e4},gemini:{id:"gemini",name:"Gemini",url:"https://gemini.google.com/app",characterLimit:32e3},grok:{id:"grok",name:"Grok",url:"https://grok.com",characterLimit:1e5},deepseek:{id:"deepseek",name:"DeepSeek",url:"https://chat.deepseek.com",characterLimit:2e5},gemini_studio:{id:"gemini_studio",name:"Gemini AI Studio",url:"https://aistudio.google.com/prompts/new_chat",characterLimit:1e5}},L=[{id:"none",name:"No Prompt (Raw Text Only)",content:"",isDefault:!0},{id:"summary",name:"Bite-Sized Summary",content:`Please summarize the following text in under 100 words.
Instructions
1. The summary should be well formatted and easily scannable.
2. Don't start the text with "Let me...", or "Here is the summary...". Just give the results.
3. Please keep it SHORT, no more than 100 words!`,isDefault:!0},{id:"5-10-points",name:"Key Point Extraction",content:`Please provide the 5-10 most important points from the text.
Use bullet points and emojis to break up the text.`,isDefault:!0},{id:"key-points-summary",name:"Full Detailed Summary",content:`Please provide a summary of the following content in its original tone:
1. First, give a concise one-sentence summary that captures the core message/theme
2. Then, share a breakdown of the main topics discussed. For each topic:
   - Expound very briefly on what was discussed on each topic
   - Include any notable quotes or statistics if any.
3. End with a brief takeaways
4. Don't go beyond 200 words.
5. Don't start the text with "Let me...", or "Here is the summary...". Just give the results.`,isDefault:!0},{id:"short-form",name:"Section-Wise Summary",content:`Summarize the following content how Blinkist would.
Keep the tone of the content. Keep it conversational.
Break the headers using relevant dynamic emojis.
Go beyond the title in giving the summary, look through entire content.
Sprinkle in quotes or excerpts to better link the summary to the content.
For less than 30 mins long content, don't go beyond 150 words.
For 1hr+ long content don't go beyond 300 words.
Don't start the text with "Let me...", or "Here is the summary...". Just give the results.`,isDefault:!0}];var d={selectedPromptId:"summary",selectedChatbotId:"chatgpt",includePrompt:!0,openChatbot:!0};async function f(){return(await chrome.storage.sync.get(["customChatbots"])).customChatbots||{}}async function x(s){await chrome.storage.sync.set({customChatbots:s})}async function g(){return(await chrome.storage.sync.get(["customPrompts"])).customPrompts||[]}async function P(s){await chrome.storage.sync.set({customPrompts:s})}async function H(){let s=await chrome.storage.sync.get(null);return{version:"1.0.0",exportDate:new Date().toISOString(),customChatbots:s.customChatbots||{},customPrompts:s.customPrompts||[],settings:s.settings||d}}async function R(s){if(!s||!s.version)throw new Error("Invalid import data format");return await chrome.storage.sync.set({customChatbots:s.customChatbots||{},customPrompts:s.customPrompts||[],settings:s.settings||d}),!0}document.addEventListener("DOMContentLoaded",async()=>{let s=document.querySelectorAll(".tab-btn"),$=document.querySelectorAll(".tab-content"),N=document.getElementById("add-prompt-btn"),I=document.getElementById("default-prompts-list"),T=document.getElementById("custom-prompts-list"),k=document.getElementById("no-custom-prompts"),_=document.getElementById("add-chatbot-btn"),S=document.getElementById("default-chatbots-list"),B=document.getElementById("custom-chatbots-list"),D=document.getElementById("no-custom-chatbots"),j=document.getElementById("open-shortcuts-btn"),z=document.getElementById("export-btn"),G=document.getElementById("import-btn"),A=document.getElementById("import-file"),q=document.getElementById("reset-btn"),i=document.getElementById("modal-overlay"),F=document.getElementById("modal-title"),O=document.getElementById("modal-body"),J=document.getElementById("modal-cancel"),K=document.getElementById("modal-save"),W=document.getElementById("modal-close"),b=document.getElementById("toast"),l=null,c=null;await w(),s.forEach(t=>{t.addEventListener("click",()=>{let e=t.dataset.tab;s.forEach(o=>o.classList.remove("active")),$.forEach(o=>o.classList.remove("active")),t.classList.add("active"),document.querySelector(`[data-content="${e}"]`).classList.add("active")})}),N.addEventListener("click",()=>U()),_.addEventListener("click",()=>M()),j.addEventListener("click",ot),z.addEventListener("click",nt),G.addEventListener("click",()=>A.click()),A.addEventListener("change",st),q.addEventListener("click",at),J.addEventListener("click",m),W.addEventListener("click",m),i.addEventListener("click",t=>{t.target===i&&m()}),K.addEventListener("click",X);async function w(){await Q(),await v(),await V(),await E()}async function Q(){I.innerHTML="",L.forEach(t=>{let e=h({name:t.name,subtitle:t.content?t.content.substring(0,80)+"...":"(No prompt text)",isDefault:!0});I.appendChild(e)})}async function v(){let t=await g();if(T.innerHTML="",t.length===0){k.style.display="block";return}k.style.display="none",t.forEach((e,o)=>{let n=h({name:e.name,subtitle:e.content.substring(0,80)+"...",isDefault:!1,onEdit:()=>U(e,o),onDelete:()=>Z(o)});T.appendChild(n)})}async function V(){S.innerHTML="",Object.values(C).forEach(t=>{let e=h({name:t.name,subtitle:t.url,isDefault:!0,badge:`${(t.characterLimit/1e3).toFixed(0)}k chars`});S.appendChild(e)})}async function E(){let t=await f();if(B.innerHTML="",Object.keys(t).length===0){D.style.display="block";return}D.style.display="none",Object.values(t).forEach(e=>{let o=h({name:e.name,subtitle:e.url,isDefault:!1,badge:`${(e.characterLimit/1e3).toFixed(0)}k chars`,onEdit:()=>M(e),onDelete:()=>et(e.id)});B.appendChild(o)})}function h({name:t,subtitle:e,isDefault:o,badge:n,onEdit:p,onDelete:ct}){let u=document.createElement("div");u.className=`list-item ${o?"default":""}`;let y=`
            <div class="item-content">
                <div class="item-name">${r(t)}</div>
                <div class="item-subtitle">${r(e)}</div>
            </div>
        `;return n&&(y+=`<span class="item-badge">${n}</span>`),o?y+='<span class="item-badge">Default</span>':y+=`
                <div class="item-actions">
                    <button class="btn-icon edit-btn" title="Edit">\u270F\uFE0F</button>
                    <button class="btn-icon danger delete-btn" title="Delete">\u{1F5D1}\uFE0F</button>
                </div>
            `,u.innerHTML=y,o||(u.querySelector(".edit-btn").addEventListener("click",p),u.querySelector(".delete-btn").addEventListener("click",ct)),u}function U(t=null,e=-1){l="prompt",c=e,F.textContent=t?"Edit Prompt":"Add Prompt",O.innerHTML=`
            <div class="form-group">
                <label for="prompt-name">Prompt Name</label>
                <input type="text" id="prompt-name" class="form-input" 
                    placeholder="e.g., Explain Like I'm 5" 
                    value="${t?r(t.name):""}">
            </div>
            <div class="form-group">
                <label for="prompt-content">Prompt Content</label>
                <textarea id="prompt-content" class="form-textarea" 
                    placeholder="Enter your prompt instructions...">${t?r(t.content):""}</textarea>
                <p class="form-help">This text will be prepended to the extracted content when sent to the chatbot.</p>
            </div>
        `,i.classList.add("show"),document.getElementById("prompt-name").focus()}function M(t=null){l="chatbot",c=t?t.id:null,F.textContent=t?"Edit Chatbot":"Add Chatbot",O.innerHTML=`
            <div class="form-group">
                <label for="chatbot-name">Chatbot Name</label>
                <input type="text" id="chatbot-name" class="form-input" 
                    placeholder="e.g., My Custom AI" 
                    value="${t?r(t.name):""}">
            </div>
            <div class="form-group">
                <label for="chatbot-url">Chat URL</label>
                <input type="url" id="chatbot-url" class="form-input" 
                    placeholder="https://example.com/chat" 
                    value="${t?r(t.url):""}">
                <p class="form-help">The URL where you can paste and chat with the AI.</p>
            </div>
            <div class="form-group">
                <label for="chatbot-limit">Character Limit</label>
                <input type="number" id="chatbot-limit" class="form-input" 
                    placeholder="40000" 
                    value="${t?t.characterLimit:"40000"}">
                <p class="form-help">Maximum characters the chatbot accepts. Default is 40,000.</p>
            </div>
        `,i.classList.add("show"),document.getElementById("chatbot-name").focus()}function m(){i.classList.remove("show"),l=null,c=null}async function X(){l==="prompt"?await Y():l==="chatbot"&&await tt()}async function Y(){let t=document.getElementById("prompt-name").value.trim(),e=document.getElementById("prompt-content").value.trim();if(!t){a("Please enter a prompt name","error");return}let o=await g(),n={id:c>=0?o[c].id:`custom-${Date.now()}`,name:t,content:e};c>=0?o[c]=n:o.push(n),await P(o),await v(),m(),a(c>=0?"Prompt updated!":"Prompt added!","success")}async function Z(t){if(!confirm("Are you sure you want to delete this prompt?"))return;let e=await g();e.splice(t,1),await P(e),await v(),a("Prompt deleted","success")}async function tt(){let t=document.getElementById("chatbot-name").value.trim(),e=document.getElementById("chatbot-url").value.trim(),o=parseInt(document.getElementById("chatbot-limit").value)||4e4;if(!t||!e){a("Please fill in all fields","error");return}try{new URL(e)}catch{a("Please enter a valid URL","error");return}let n=await f(),p=c||`custom-${Date.now()}`;n[p]={id:p,name:t,url:e,characterLimit:o},await x(n),await E(),m(),a(c?"Chatbot updated!":"Chatbot added!","success")}async function et(t){if(!confirm("Are you sure you want to delete this chatbot?"))return;let e=await f();delete e[t],await x(e),await E(),a("Chatbot deleted","success")}function ot(){navigator.userAgent.includes("Firefox")?chrome.tabs.create({url:"about:addons"}):chrome.tabs.create({url:"chrome://extensions/shortcuts"})}async function nt(){try{let t=await H(),e=new Blob([JSON.stringify(t,null,2)],{type:"application/json"}),o=URL.createObjectURL(e),n=document.createElement("a");n.href=o,n.download=`content-extractor-backup-${new Date().toISOString().split("T")[0]}.json`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(o),a("Settings exported successfully!","success")}catch(t){a("Export failed: "+t.message,"error")}}async function st(t){let e=t.target.files[0];if(e){try{let o=await e.text(),n=JSON.parse(o);if(!n.version)throw new Error("Invalid backup file format");await R(n),await w(),a("Settings imported successfully!","success")}catch(o){a("Import failed: "+o.message,"error")}t.target.value=""}}async function at(){confirm("Are you sure you want to reset all settings? This will delete all custom prompts and chatbots.")&&confirm("This action cannot be undone. Are you absolutely sure?")&&(await chrome.storage.sync.clear(),await chrome.storage.sync.set({initialized:!0,settings:d,customChatbots:{},customPrompts:[]}),await w(),a("All settings have been reset","success"))}function a(t,e="info"){b.textContent=t,b.className=`toast ${e} show`,setTimeout(()=>{b.classList.remove("show")},3e3)}function r(t){let e=document.createElement("div");return e.textContent=t,e.innerHTML}});})();
